
function attachEvents() {
    BASE_URL = 'http://localhost:3030/jsonstore/tasks/'

    loadBtn = document.getElementById('load-board-btn');
    loadBtn.addEventListener('click',loadBoard)

    addBtn = document.getElementById('create-task-btn');
    addBtn.addEventListener('click',addTaskHandler)

    toDoBoard = document.getElementsByClassName('task-list')[0]
    inProgressBoard = document.getElementsByClassName('task-list')[1]
    codereviewBoard = document.getElementsByClassName('task-list')[2]
    doneBoard = document.getElementsByClassName('task-list')[3]

    titleInput = document.getElementById('title')
    descInput = document.getElementById('description')

    function loadBoard() {
        fetch(BASE_URL)
            .then(res => res.json())
            .then((loadedProducts)=> {

                toDoBoard.innerHTML = ''
                inProgressBoard.innerHTML = ''
                codereviewBoard.innerHTML = ''
                doneBoard.innerHTML = ''


                tasks = Object.values(loadedProducts)
                for (const { title, description, status, _id} of tasks){
                    li = createElement('li',null,null,['task'])
                    h3 = createElement('h3',li,title,)
                    p = createElement('p',li,description)
                    if (status === 'ToDo'){
                        button = createElement('button',li,'Move to In Progress')
                        toDoBoard.appendChild(li)
                    } else if (status === 'In Progress'){
                        button = createElement('button',li,'Move to Code Review')
                        inProgressBoard.appendChild(li)
                    } else if (status === 'Code Review'){
                        button = createElement('button',li,'Move to Done')
                        codereviewBoard.appendChild(li)
                    } else if (status === 'Done'){
                        button = createElement('button',li,'Close')
                        doneBoard.appendChild(li)
                    }

                }
                

            })
        console.log(toDoBoard)
    }

    function addTaskHandler(){
        titleInputPush = titleInput.value
        descInputPush = descInput.value

        httpHeaders = {
            method: 'POST',
            body: JSON.stringify({
                title: titleInputPush,
                description: descInputPush,
                status: 'ToDo'})
          }
        fetch(BASE_URL,httpHeaders)
          .then(res=>res.json())
          loadBoard()

          titleInput.value = ''
          descInput.value = ''
    }

    function createElement(type, parentNode, content, classes, id, attributes, useInnerHTML) {
        const htmlElement = document.createElement(type);
        if (content && useInnerHTML) {
          htmlElement.innerHTML = content;
        } else {
          if (content && type !== 'input'){
            htmlElement.textContent = content;
          }
      
          if (content && type === 'input'){
            htmlElement.value = content;
            }
          }
        if (classes && classes.length > 0){
          htmlElement.classList.add(...classes);
        }  
        if (id) {
          htmlElement.id = id;
        }
        if (attributes){
          for (const key in attributes){
            htmlElement.setAttribute(key, attributes[key])};
        }
        if (parentNode){
          parentNode.appendChild(htmlElement);
        }
        return htmlElement
      }
}

attachEvents();